﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using System.IO;
using System.Text.RegularExpressions;

class Part2
{
    // Azure OpenAI endpoint and API key
    private static readonly string openAiEndpoint = "https://st104-m8lrvi5o-eastus2.cognitiveservices.azure.com";
    private static readonly string apiKey = "48lE2frmWq1JlArHzpjADDdvxy6jEm8N3jpPTWRLoEyqnvczB30cJQQJ99BCACHYHv6XJ3w3AAAAACOG9hZf";
    private static readonly string deploymentName = "LifeOChatBot";
    private static readonly string apiVersion = "2025-01-01-preview";

    // User's name and interest, which help personalize responses
    private static string userName = "";
    private static string userInterest = "";

    // Cancellation token for handling inactivity
    private static CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();

    // List to store the entire conversation history
    private static List<string> conversationHistory = new List<string>();

    // To store the last misunderstood input for possible retry
    private static string lastMisunderstoodInput = null;

    // Misspelled words dictionary to offer correction suggestions
    private static Dictionary<string, string> misspelledWords = new Dictionary<string, string>();

    // Predefined responses for certain keywords to speed up responses
    private static readonly Dictionary<string, List<string>> keywordResponses = new Dictionary<string, List<string>>()
    {
        { "password", new List<string> {
            "Use a strong password with letters, numbers, and symbols.",
            "Avoid using personal details in your passwords.",
            "Consider using a password manager to store your passwords safely.",
            "Change your passwords regularly, especially after a breach.",
            "Use different passwords for different accounts to reduce risk."
        }},
        { "scam", new List<string> {
            "Be cautious of unsolicited messages asking for personal info.",
            "Scammers often impersonate trusted organizations—verify sources!",
            "Never click unknown links or download unexpected attachments.",
            "Double-check URLs for misspellings or strange characters.",
            "Don't share OTPs or PINs with anyone, even if they claim to be officials."
        }},
        { "privacy", new List<string> {
            "Regularly check and update your social media privacy settings.",
            "Limit the amount of personal info you share online.",
            "Use encryption and VPNs to help maintain online privacy.",
            "Turn off location tracking on apps you don’t need it for.",
            "Be cautious about granting permissions to apps on your phone."
        }},
        { "phishing", new List<string> {
            "Watch for emails with urgent messages or threats—they might be phishing.",
            "Don't click links in suspicious emails—hover over to check them first.",
            "Check the sender's email address for slight misspellings or fakes.",
            "Avoid opening attachments from unknown or unexpected sources.",
            "Look for generic greetings like 'Dear Customer'—they're a red flag."
        }},
        { "malware", new List<string> {
            "Keep your software and antivirus updated to defend against malware.",
            "Avoid downloading files or apps from untrusted sources.",
            "Be cautious of email attachments even if they appear to be from someone you know.",
            "Don’t ignore pop-up warnings from your antivirus or browser.",
            "Run regular malware scans to detect hidden threats."
        }},
        { "ransomware", new List<string> {
            "Backup important files regularly to protect against ransomware.",
            "Avoid clicking on suspicious links or downloading unexpected attachments.",
            "Use updated antivirus software that can detect ransomware.",
            "Be wary of email attachments from unknown senders.",
            "Educate yourself about social engineering tactics."
        }},
        { "2fa", new List<string> {
            "Enable two-factor authentication (2FA) for all critical accounts.",
            "Use an authenticator app instead of SMS when possible.",
            "Don't share your 2FA codes with anyone.",
            "Keep backup codes stored securely in case you lose access.",
            "Be cautious of fake 2FA prompts used in phishing."
        }}
    };

    // Responses based on sentiment detection (simplified for this example)
    private static readonly Dictionary<string, string> sentimentResponses = new Dictionary<string, string>()
    {
        { "worried", "{userName}, it's okay to feel worried about scammers and phishing. These threats are real, but your awareness is your shield—I'm here to help you strengthen it." },
        { "curious", "Being curious about cybersecurity, {userName}, is a superpower. The more you learn, the better you’ll be at spotting scams and staying safe online." },
        { "frustrated", "Frustrated by all the scams and cyber risks? I get it, {userName}. But every bit of knowledge you gain makes you stronger and harder to fool." },
        { "angry", "You have every right to be angry at cybercriminals, {userName}. But guess what? Learning how to outsmart them puts the power back in your hands." }
    };

    // Main entry point for the program
    public static async Task Main(string[] args)
    {
        await InitializeBot();
    }

    // Initialize the bot and greet the user
    public static async Task InitializeBot()
    {
        Console.ForegroundColor = ConsoleColor.Yellow;
        Console.WriteLine("========================================================================================================================");
        Console.WriteLine("                                 Welcome to part 2 of the POE                                                           ");
        Console.WriteLine("========================================================================================================================");

        // Ask for user's name and customize greeting based on time of day
        Console.Write("Please enter your name: ");
        userName = Console.ReadLine();

        string greeting = GetGreetingBasedOnTimeOfDay();
        Console.ForegroundColor = ConsoleColor.Green;
        Console.WriteLine($"\n{greeting}, {userName}!. You can ask me anything about cybersecurity or type 'exit' to leave.\n");
        Console.ResetColor();

        // Start handling user inputs
        await HandleUserInputs();
    }

    // Get greeting based on the current time of day
    public static string GetGreetingBasedOnTimeOfDay()
    {
        int hour = DateTime.Now.Hour;
        if (hour >= 5 && hour < 12) return "Good morning";
        if (hour >= 12 && hour < 17) return "Good afternoon";
        return "Good evening";
    }

    // Handle user inputs, including inactivity timeout and conversation continuation
    public static async Task HandleUserInputs()
    {
        while (true)
        {
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.Write($"{userName}: ");
            string input = SanitizeInput(Console.ReadLine());
            Console.ResetColor();

            // If input is empty, ask user to provide something
            if (string.IsNullOrWhiteSpace(input))
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("Bot: Please enter something so I can help you.\n");
                Console.ResetColor();
                continue;
            }

            // Exit condition
            if (input == "exit") break;

            // Handle requests for conversation summary
            if (input.Contains("summarize") || input.Contains("summary"))
            {
                string summary = await GetAIResponse("Summarize this conversation in a helpful way.");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine($"Bot: Here's a summary of our chat: {summary}\n");
                Console.ResetColor();
                continue;
            }

            // Handle suggestions if user doesn't know what to ask
            if (input.Contains("i don't know") || input.Contains("what should i ask"))
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("Bot: You could ask me about phishing scams, password safety, privacy settings, or malware risks.\n");
                Console.ResetColor();
                continue;
            }

            // Reset the inactivity timer for each new input
            cancellationTokenSource.Cancel();
            cancellationTokenSource = new CancellationTokenSource();
            _ = StartInactivityTimer(cancellationTokenSource.Token);

            // Get the bot's response and display it
            string response = await GetSmartResponse(input);

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"Bot: {response}\n");
            Console.ResetColor();
        }

        // Ask if user wants to export the chat log
        Console.Write("Would you like to export this session? (yes/no): ");
        string export = Console.ReadLine().ToLower();
        if (export == "yes")
        {
            File.WriteAllLines("chatlog.txt", conversationHistory);
            Console.WriteLine("Bot: Chat history saved to 'chatlog.txt'.");
        }
    }

    // Sanitize user input to remove unwanted characters (e.g., spaces, punctuation)
    public static string SanitizeInput(string input)
    {
        return Regex.Replace(input.ToLower().Trim(), "[^a-zA-Z0-9 ?!']", "");
    }

    // Generate a smart response based on user input and context
    public static async Task<string> GetSmartResponse(string userInput)
    {
        // Check for sentiment-related responses
        foreach (var sentiment in sentimentResponses)
        {
            if (userInput.Contains(sentiment.Key))
                return sentiment.Value.Replace("{userName}", userName);
        }

        // Check if the input matches a known misspelled word and offer a corrected suggestion
        if (misspelledWords.ContainsKey(userInput))
        {
            string correctedWord = misspelledWords[userInput];
            misspelledWords.Remove(userInput);
            return $"Oh, I understand now! You meant '{correctedWord}'. Here's what I can help with: {await GetAIResponse(userInput)}";
        }

        // Check for "interested in" keyword to personalize advice
        if (userInput.Contains("interested in"))
        {
            userInterest = userInput.Substring(userInput.IndexOf("interested in") + 13).Trim();
            return $"Great, {userName}! I'll remember that you're interested in {userInterest}. It's a crucial part of staying safe online.";
        }

        // Handle requests to remind the user of their interest
        if (!string.IsNullOrEmpty(userInterest) && userInput.Contains("remind me"))
        {
            return $"As someone interested in {userInterest}, {userName}, remember to review your account security settings.";
        }

        // Check for known keywords and offer a predefined response
        foreach (var keyword in keywordResponses.Keys)
        {
            if (userInput.Contains(keyword) || LevenshteinDistance(userInput, keyword) <= 2)
            {
                var tips = keywordResponses[keyword];
                var rand = new Random();
                return tips[rand.Next(tips.Count)];
            }
        }

        // Handle short inputs that may be a continuation of a previous message
        if (lastMisunderstoodInput != null && userInput.Split(' ').Length <= 3)
        {
            string combined = $"{lastMisunderstoodInput} {userInput}";
            lastMisunderstoodInput = null;
            return await GetAIResponse(combined);
        }

        // Get response from AI if no other conditions were met
        string aiResponse = await GetAIResponse(userInput);

        // If AI response is unsure, flag the last misunderstood input for potential retry
        if (aiResponse.ToLower().Contains("i'm not sure") || aiResponse.ToLower().Contains("rephrase"))
        {
            lastMisunderstoodInput = userInput;
            misspelledWords[userInput] = userInput;
        }
        else
        {
            lastMisunderstoodInput = null;
        }

        return aiResponse;
    }

    // Get a response from the AI (Azure OpenAI API)
    public static async Task<string> GetAIResponse(string userQuery)
    {
        try
        {
            // Add the user query to the conversation history
            conversationHistory.Add($"User: {userQuery}");

            using (HttpClient client = new HttpClient())
            {
                client.DefaultRequestHeaders.Add("api-key", apiKey);

                // Build the message history for context
                var messages = new List<object>
                {
                    new
                    {
                        role = "system",
                        content = $"You are a professional, friendly cybersecurity assistant named LifeOChatBot. Your role is to help the user, {userName}, with any cybersecurity-related questions in a helpful, clear, and engaging way. You must remember previous messages in the session to understand if the user is following up, needs more explanation, or is continuing the same topic. If a user follows up or asks something short, assume it's a continuation unless it's clearly a new topic."
                    }
                };

                // Add the conversation history to the messages
                foreach (var message in conversationHistory)
                {
                    messages.Add(new
                    {
                        role = message.StartsWith("User") ? "user" : "assistant",
                        content = message.Substring(6)
                    });
                }

                var requestBody = new
                {
                    messages = messages.ToArray(),
                    max_tokens = 200,
                    temperature = 0.7
                };

                // Make the API request
                var content = new StringContent(JsonSerializer.Serialize(requestBody), Encoding.UTF8, "application/json");
                string requestUri = $"{openAiEndpoint}/openai/deployments/{deploymentName}/chat/completions?api-version={apiVersion}";

                HttpResponseMessage response = await client.PostAsync(requestUri, content);

                // If the API call was successful, return the response from the bot
                if (response.IsSuccessStatusCode)
                {
                    string responseBody = await response.Content.ReadAsStringAsync();
                    var jsonResponse = JsonSerializer.Deserialize<JsonElement>(responseBody);
                    var botResponse = jsonResponse.GetProperty("choices")[0].GetProperty("message").GetProperty("content").GetString().Trim();

                    conversationHistory.Add($"Bot: {botResponse}");
                    return botResponse;
                }
                else
                {
                    return "I'm not sure I understand. Can you try rephrasing?";
                }
            }
        }
        catch (Exception ex)
        {
            return $"I had trouble connecting. Please try again. Error: {ex.Message}";
        }
    }

    // Start a timer that handles inactivity by offering personalized advice
    public static async Task StartInactivityTimer(CancellationToken token)
    {
        try
        {
            // Wait for 15 seconds of inactivity
            await Task.Delay(15000, token);

            // If user has an interest, provide a personalized advice
            if (!string.IsNullOrEmpty(userInterest))
            {
                string aiAdvice = await GetAIResponse($"Give short and useful cybersecurity advice about {userInterest}");

                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine($"\nBot: Here's some personalized advice for you, {userName}: {aiAdvice}\n");
                Console.ResetColor();

                Console.ForegroundColor = ConsoleColor.Blue;
                Console.Write($"{userName}: ");
                Console.ResetColor();
            }
        }
        catch (TaskCanceledException)
        {
            // Timer was cancelled - user is active
        }
    }

    // Levenshtein distance algorithm to measure how close two words are
    public static int LevenshteinDistance(string s, string t)
    {
        int[,] d = new int[s.Length + 1, t.Length + 1];

        // Initialize base cases
        for (int i = 0; i <= s.Length; i++) d[i, 0] = i;
        for (int j = 0; j <= t.Length; j++) d[0, j] = j;

        // Fill in the distance matrix
        for (int i = 1; i <= s.Length; i++)
        {
            for (int j = 1; j <= t.Length; j++)
            {
                int cost = s[i - 1] == t[j - 1] ? 0 : 1;
                d[i, j] = Math.Min(Math.Min(d[i - 1, j] + 1, d[i, j - 1] + 1), d[i - 1, j - 1] + cost);
            }
        }

        return d[s.Length, t.Length];
    }
}
